﻿export const mockNotifications: any[] = [];
