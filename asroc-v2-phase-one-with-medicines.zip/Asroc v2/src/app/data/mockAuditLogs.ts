﻿export const mockAuditLogs: any[] = [];
