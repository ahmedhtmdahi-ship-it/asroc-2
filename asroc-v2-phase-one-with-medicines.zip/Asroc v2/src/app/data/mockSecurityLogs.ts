﻿export const mockSecurityLogs: any[] = [];
